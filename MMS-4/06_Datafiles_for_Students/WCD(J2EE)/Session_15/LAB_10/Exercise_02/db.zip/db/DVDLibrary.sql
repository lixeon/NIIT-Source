--  SL-314-exercises database creation script
--  This script was created for use with Derby
-- 
--  To use this script to build/re-create the database, do the
--  following:
--
--  1. Start the Derby Database Server
--  2. Create the sl351-exercises database using dvd as username and password
--  3. Populate the database:		
--	Go to the terminal window and type the following commands:
--   		C:\Sun\AppServer\derby>java -cp lib\derbyclient.jar;lib\derbytools.jar org.apache.derby.tools.ij
--		ij version 10.1
--		ij> connect 'jdbc:derby://localhost:1527/dvdlibrary;user=public;password=public';
--		ij> run 'C:\student\resources\sql\SL314-initialize.sql';

-- Clear out the old table.
DROP TABLE ObjectIDs;
DROP TABLE Item;

--
-- This table represents the "next" object_ID for a given table.
--
CREATE TABLE ObjectIDs (
-- PRIMARY KEY --
   table_name  VARCHAR(30) PRIMARY KEY,
-- DATA FIELDS --
   id          INTEGER NOT NULL
);

--
-- This table represents the DVD Items
--
CREATE TABLE Item (
-- PRIMARY KEY --
   id          INTEGER PRIMARY KEY,  
-- DATA FIELDS --
   username    VARCHAR(20) NOT NULL, 
   title       VARCHAR(100) NOT NULL, 
   "year"        CHAR(4) NOT NULL,     
   genre       VARCHAR(20) NOT NULL  
);


-- Data template SQL script.
-- This file is used by Ant to create a user-specific data.sql file
-- that is then imported into the database

INSERT INTO Item VALUES(1,'jack','The Godfather','1972','Drama');

INSERT INTO Item VALUES(2,'jack','The Shawshank Redemption','1994','Drama');

INSERT INTO Item VALUES(3,'jack','The Godfather: Part II','1974','Drama');

INSERT INTO Item VALUES(4,'jack','The Lord of the Rings: The Return of the King','2003','Fantasy');

INSERT INTO Item VALUES(5,'jack','The Lord of the Rings: The Two Towers','2002','Fantasy');

INSERT INTO Item VALUES(6,'jack','Shindler''s List','1998','Drama');

INSERT INTO Item VALUES(7,'jack','Shichinin no samurai','1954','Action');

INSERT INTO Item VALUES(8,'jack','Casablanca','1942','Drama');

INSERT INTO Item VALUES(9,'jack','The Lord of the Rings: The Fellowship of the Ring','2001','Fantasy');

INSERT INTO Item VALUES(10,'jack','Star Wars','1977','Sci-Fi');

INSERT INTO Item VALUES(11,'jack','Citizen Kane','1941','Mystery');

INSERT INTO Item VALUES(12,'jack','One Flew Over the Cuckoo''s Nest','1975','Drama');

INSERT INTO Item VALUES(13,'jack','Dr. Strangelove or: How I Learned to Stop Worrying and Love the Bomb','1964','Comedy');

INSERT INTO Item VALUES(14,'jack','Rear Window','1954','Thriller');

INSERT INTO Item VALUES(15,'jack','Star Wars: Episode V - The Empire Strikes Back','1980','Sci-Fi');

INSERT INTO Item VALUES(16,'jack','Raiders of the Lost Ark','1981','Action');

INSERT INTO Item VALUES(17,'jack','The Usual Suspects','1995','Mystery');

INSERT INTO Item VALUES(18,'jack','Pulp Fiction','1994','Crime');

INSERT INTO Item VALUES(19,'jack','Memento','2000','Mystery');

INSERT INTO ObjectIds (table_name, id) VALUES('Item', 20);

COMMIT;
