using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for DataHelper
/// </summary>
public class DataHelper
{
    
    public DataHelper()
	{
	}
    public static string getBalance(string acc_no)
    {
        DataSet ds;
        SqlConnection con;
        SqlDataAdapter da;
        SqlCommand com;
        string bal;
        con = new SqlConnection();
        con.ConnectionString = "Data Source=.;Initial Catalog=SaveMyMoneyBank;User ID=sa;Password=;";
                   con.Open();
        da = new SqlDataAdapter();
        com = new SqlCommand("select CurrentBalance from account_details where AccountNo=@acc",con);        
        com.Parameters.Add("@acc", SqlDbType.NVarChar);       
        com.Parameters[0].Value = acc_no;
        da.SelectCommand = com;
        ds = new DataSet();
        da.Fill(ds, "account_details");
        bal = (string)ds.Tables[0].Rows[0].ItemArray[0];
        return bal;
        
    }
}
