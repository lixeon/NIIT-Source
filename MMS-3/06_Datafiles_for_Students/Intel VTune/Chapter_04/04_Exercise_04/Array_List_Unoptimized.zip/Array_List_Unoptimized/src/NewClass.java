
public class NewClass 
{   
   public NewClass() {}
   public int[] arr1=new int[100];
   public int[] arr2=new int[100];
   public int[] arr3=new int[100];
   
   
   public void create()
   {   
      
       System.out.println("First generator:");    
 
       for(int i=0;i<100;i++)
       {          
           arr1[i]=(i+1);
       }
       for(int i=0;i<100;i++)
       {          
           arr2[i]=(i*2);
       }
   }
   
   public void sum()
   {       
        for(int i=0;i<100;i++)
       {          
           arr3[i]=arr1[i]+arr2[i];
       }
        
        System.out.println("\n\nAfter addition....");
        for(int i=0;i<100;i++)
       {          
            System.out.print(arr3[i]+"  ");
       }
        
   }
   
   public void display()
   {
       System.out.println("Array 1 is......");
       for(int i=0;i<100;i++)
       {          
            System.out.print(arr1[i]+"  ");
       }
       
       System.out.println("\n\nArray 2 is......");
       for(int i=0;i<100;i++)
       {          
            System.out.print(arr2[i]+"  ");
       }
   }
   
   public static void main(String args[])
   {
        NewClass n=new NewClass();
        n.create();
        n.display();
        n.sum();
   }
}
