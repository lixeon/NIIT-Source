using System;
using System.Collections.Generic;
using System.Text;

namespace Natural_numbers_sum
{
    class Program
    {
        int num=10000;
        int[] arr;
        public void accept()
        {
            arr = new int[num];
            for (int i = 0; i < num; i++)
            {
                arr[i] = i;
            }
            Console.WriteLine("\nThe array is....\n");
            for (int i = 0; i < num; i++)
            {
                Console.Write(i.ToString() + "\t");
            }
            Console.WriteLine("\n");
        }
        public int add()
        {
            int sum=0;            
            for (int i = 0; i < num; i++)
                sum += arr[i];
            return sum;
        }
        static void Main(string[] args)
        {
            int sum;
            Program obj = new Program();
            obj.accept();
            sum=obj.add();
            Console.Write("Do you want to view the sum? (y/n): ");
            char ch = Convert.ToChar(Console.ReadLine());
            if (ch == 'y' || ch == 'Y')
            {
                Console.Write("\nThe sum is: " + sum);
                Console.ReadLine();
            }
        }
    }
}
