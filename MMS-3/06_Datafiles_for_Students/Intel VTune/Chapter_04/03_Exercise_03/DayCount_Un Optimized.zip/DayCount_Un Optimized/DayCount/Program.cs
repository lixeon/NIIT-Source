using System;
namespace PrimarySchool
{
    class DayCount
    {
        int Month;
        int Year;
        int Days;

        public DayCount() //Constructor to initialize month and year to 0
        {
            Month = 0;
            Year = 0;
        }
        //Returns 1 if year is a leap year, else returns 0
        public Boolean LeapYear()
        {
            if (Year % 4 == 0)
                return true;
            else
                return false;
        }

        //Sets the month and year
        public void setDate(int month1, int year1)
        {
            Year = year1;
            Month = month1;
        }      

        //Returns the name of the month 
        public string monthName()
        {
            if(Month==1)
                return "January";
            else if(Month==2)               
                 return "February";
            else if(Month==3)  
                 return "March";
             else if(Month==4)  
                return "April";
             else if(Month==5)  
                return "May";
             else if(Month==6)  
                return "June";
             else if(Month==7)  
                return "July";
             else if(Month==8)  
                return "August";
             else if(Month==9)  
                return "September";
             else if(Month==10)  
                return "October";
             else if(Month==11)  
                return "November";
            else if (Month == 12)  
                return "December";
            else
                return "Invalid Month Specified!";        

        }
        //Sets the number of days in a month
        public void setDays()
        {
            if(Month==1)
                Days=31;
            else if (Month == 3) 
                Days=31;
            else if (Month == 5)  
                Days=31;
            else if (Month == 7) 
                Days=31;
            else if (Month == 8)  
                Days=31;
            else if (Month == 10)
                Days=31;
            else if (Month == 12) 
                Days=31;
            else if (Month == 2) 
            {
                Days=28;
                if (LeapYear())
                      Days = 29; 
            }            
            else if (Month == 4)  
                Days = 30;
            else if (Month == 6) 
                Days = 30;
            else if (Month == 9) 
                Days = 30;
            else if (Month == 11) 
                Days = 30;
                
            }
         public void display()
        {
            string[] name = new string[25];
            setDays();
            Console.Write("The number of days in the month of " + monthName());
            Console.Write(" is " + Days);
        }

        static void Main(string[] args)
        {
            DayCount dayCount = new DayCount();
            int month, year;
            char ch;
            while (true)
            {
                Console.WriteLine("Enter the month in number:");
                month = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the year :");
                year = Convert.ToInt32(Console.ReadLine());
                dayCount.setDate(month, year);
                dayCount.display();
                Console.WriteLine("\nWant to continue? (y/n): ");
                ch=Convert.ToChar(Console.ReadLine());
                if (ch == 'y' || ch == 'Y')
                    continue;
                else
                    break;
            }
            Console.ReadLine();
        }
        }
       

        
    }


