using System;
using System.Collections.Generic;
using System.Text;

namespace Natural_Numbers
{
    class Program
    {
        int[] operand;
        int n;
        public void display()
        {
            operand = new int[n];
            for (int i = 0; i < n; i++)
            {
                operand[i] = (i + 1);
            }

            Console.WriteLine("The numbers are:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("\n " + operand[i]);
            }
        }

        public void calculate()
        {
            Random rnd = new Random();
            operand = new int[n];

            for (int i = 0; i < n; i++)
            {
                operand[i] = (i + 1);
            }

            int VAL = 0;
            for (int i = 0; i < n; i++)
            {
                VAL = VAL + operand[i];
            }
            Console.WriteLine("The sum is:" + Convert.ToString(VAL));
        }
        static void Main(string[] args)
        {
            Program obj = new Program();

            char ch;
            Console.Write("Enter the total number of natural numbers: ");
            obj.n = Convert.ToInt32(Console.ReadLine());
            while (true)
            {
                Console.WriteLine("\n1. Display all the numbers.");
                Console.WriteLine("2. Add all the numbers.");
                Console.WriteLine("3.Exit");
                Console.Write("Enter your choice: ");
                ch = Convert.ToChar(Console.ReadLine());
                switch (ch)
                {
                    case '1':
                        {
                            obj.display();
                        }
                        break;
                    case '2':
                        {
                            obj.calculate();
                        }
                        break;
                    case '3':
                        {
                            return;
                        }
                }
            }
            Console.ReadLine();
        }
    }
}



