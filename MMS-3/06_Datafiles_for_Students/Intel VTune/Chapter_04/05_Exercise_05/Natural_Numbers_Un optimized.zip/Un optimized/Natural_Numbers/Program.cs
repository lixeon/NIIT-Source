using System;
using System.Collections.Generic;
using System.Text;

namespace Natural_Numbers
{
    class Program
    {
        int[] operand;
        int n=10000;
        public void display()
        {
            operand = new int[n];
            for (int i = 0; i < n; i++)
            {
                operand[i] = (i + 1);
            }

            Console.WriteLine("The numbers are:");
            for (int i = 0; i < n; i++)
            {
                Console.Write(operand[i]+"\t");
            }
        }

        public void calculate()
        {           
            operand = new int[n];
            for (int i = 0; i < n; i++)
            {
                operand[i] = (i + 1);
            }
            int VAL = 0;
            for (int i = 0; i < n; i++)
            {
                VAL = VAL + operand[i];
            }
            Console.WriteLine("\n\nThe sum is:" + Convert.ToString(VAL));
        }
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.display();
            obj.calculate();           
            Console.ReadLine();
        }
    }
}



