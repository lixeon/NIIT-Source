using System;
using System.Collections.Generic;
using System.Text;

namespace Factorial
{
    class Program
    {
        int result;
        int fact(int n)
        {
            if (n == 0)
                return 1;
            if (n ==1 )
                return 1;
            else
            {
                result = n * fact(n - 1);               
            }
            return result;               
        }

        static void Main(string[] args)
        {
            Program obj = new Program();
            int val,r;
            Console.Write("Enter a number: ");
            val = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nThe factorial is: ");
            r = obj.fact(val);
            Console.Write(r.ToString());
            Console.ReadLine();
        }
    }
}
