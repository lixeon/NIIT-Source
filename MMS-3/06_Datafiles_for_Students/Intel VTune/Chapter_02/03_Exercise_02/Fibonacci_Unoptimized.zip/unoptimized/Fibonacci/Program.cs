using System;
using System.Collections.Generic;
using System.Text;

namespace Fibonacci
{
    class Program
    {
        public int count = 1;
        public int fib(int n)
        {            
            if (n == 0)
            {
                count++;
                return 0;
                count++;
            }
            else if (n == 1)
            {
                count++;
                return 1;
                count++;
            }
            int x1;
            count++;
            int f;
            count++;
            int x2;
            count++;
            x1 = 0;
            count++;
            f = 1;
            count++;
            x2 = 1;
            count++;
            if (n >= 1)
            {
                count = count + 2;
                for (int i = 2; i <= n; i++)
                {
                    f = x1 + x2;
                    count++;
                    x1 = x2;
                    count++;
                    x2 = f;
                    count++;
                }
            }
            count++;
            return f;
        }

        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.count++;
            Console.Write("Enter a number: ");
            obj.count++;
            int num = Convert.ToInt32(Console.ReadLine());
            obj.count = obj.count + 2;
            for (int i = 2; i <= num; i++)
            {
                obj.count++;
                Console.WriteLine(obj.fib(i));
            }
            Console.ReadLine();
            obj.count++;

        }
    }
}
