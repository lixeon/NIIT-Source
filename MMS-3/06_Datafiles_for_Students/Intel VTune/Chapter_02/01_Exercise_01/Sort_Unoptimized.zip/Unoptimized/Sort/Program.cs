using System;
using System.Collections.Generic;
using System.Text;

namespace Sort
{
    class Program
    {
        public int Count=1;
        public void func()
        {
            int[] a = new int[] { 4, 2, 8, 45, 21, 0, 33, 88, 99, 10 };
            Count++;
            int k;
            Count++;
            int temp;
            Count++;
            int ptr;
            Count++;
            int n = 10;
            Count++;
            a[0] = -1;
            Count=Count+2;
            for (k = 1; k < n; k++)
            {
                temp = a[k];
                Count++;
                ptr = k - 1;
                Count = Count + 2;
                while (temp < a[ptr])
                {
                    a[ptr + 1] = a[ptr];
                    Count++;
                    ptr--;
                    Count++;
                }
                a[ptr + 1] = temp;
                Count++;
            }
            Count++;
            for (int l = 0; l < n; l++)
            {
                Console.WriteLine(a[l]);
                Count++;
            }
        }
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.Count++;
            obj.func();
            obj.Count++;
            Console.ReadLine();
            obj.Count++;
        }
    }
}
