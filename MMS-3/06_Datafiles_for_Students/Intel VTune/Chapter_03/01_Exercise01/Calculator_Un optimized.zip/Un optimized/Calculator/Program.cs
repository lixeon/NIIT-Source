using System;
using System.Collections.Generic;
using System.Text;

namespace Calculator
{
    class Calc
    {
        Random rnd=new Random();
        char operation;
        int []operand=new int[100000];
        public Calc()
        {
            for (int i=0; i<100000; i++)
	        {
	            operand[i]=Convert.ToInt32((rnd.Next()%10)+1);
	        }
        }
        public void display()
	    {
	        Console.WriteLine("The values in the array are:");
            for (int i = 0; i < 100000; i++)
            {
                Console.Write("\n " + operand[i]);
            }
	    }
        public void operate()
        {
            Console.WriteLine("\nEnter any of the following: \n + \n * \n");
            operation = Convert.ToChar(Console.ReadLine());
            int VAL = 1;
            if(operation=='+')
              {
                int i = 0;
                while (i < 100000)
                {
                    VAL = VAL + operand[i];
                    i = i + 1;
                }                        
                Console.WriteLine(VAL - 1);                        
               }
            else if(operation== '*')
                {
                    int i = 0;
                    while (i < 100000)
                    {
                        VAL = VAL * operand[i];
                        i = i + 1;
                    }                        
                    Console.WriteLine(VAL);                        
                }
            else
                {
                    Console.WriteLine("enter a vaild response");                       
                }            
            }       
        
        static void Main(string[] args)
        {
            Calc calculator=new Calc();
            calculator.display();
            calculator.operate();
            Console.ReadLine();
        }
    }
}
