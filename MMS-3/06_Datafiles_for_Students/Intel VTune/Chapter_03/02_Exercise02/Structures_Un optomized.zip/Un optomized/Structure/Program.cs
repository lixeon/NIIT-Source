using System;
using System.Collections.Generic;
using System.Text;

namespace Structure
{
    class Program
    {
        public struct DOB
        {
            public int day;
            public int month;
            public int year;
        }

        public struct student
        {
            public int roll_no;
            public string name;
            public DOB dt_of_brth;
        }
        public student[] starr= new student[10];
        public string facname;
		public void getdata()
		{            
            int i=0;
            while(i < 2)
            {
		        Console.Write("Enter the roll number of the student: ");
                starr[i].roll_no = Convert.ToInt16(Console.ReadLine());
                Console.Write("Enter the student name: ");		    
		        starr[i].name=Convert.ToString(Console.ReadLine());
		        starr[i].dt_of_brth = new DOB();
                Console.Write("Enter the Date of Birth :\n\n");
		        Console.Write("year: ");
		        starr[i].dt_of_brth.year=Convert.ToInt32(Console.ReadLine());
		        Console.Write("Month: ");
		        starr[i].dt_of_brth.month=Convert.ToInt32(Console.ReadLine());
		        Console.Write("Day: ");
		        starr[i].dt_of_brth.day=Convert.ToInt32(Console.ReadLine());   
                i=i+1;
            }        
            Console.WriteLine("Enter the name of the faculty: ");
            facname = Convert.ToString(Console.ReadLine());
		}

        public void finddata(int month_num)
        {
            int i = 0;
            if (starr[i].dt_of_brth.month == month_num)
                {
                    Console.WriteLine("\nThe student born in April: " + starr[i].name);
                }
            i=i+1;
            if (i < 2)
            {
                if (starr[i].dt_of_brth.month == month_num)
                {
                    Console.WriteLine("\nThe student born in April: " + starr[i].name);
                }
            }
            else
                return;
                       
        }
        static void Main(string[] args)
        {
            Program ptr=new Program();
            ptr.getdata();
            ptr.finddata(4);
            Console.ReadLine();
        }
    }
}