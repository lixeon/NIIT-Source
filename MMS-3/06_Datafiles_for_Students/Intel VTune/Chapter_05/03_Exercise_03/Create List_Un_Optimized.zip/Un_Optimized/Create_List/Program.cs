using System;
using System.Collections.Generic;
using System.Text;

namespace Create_List
{
    class Program
    {
        int num = 10000;
        int[] arr=new int[10000];
        public void add()
        {
            for (int i = 0; i < num; i++)
            {
                arr[i] = (i + 1);
            }            
        }

        public void remove()
        {
            if (num == 0)
            {
                Console.WriteLine("\nThe list is empty");
                return;
            }
            for (int a = 0; a < 1000; a++)
            {
                int j = 0;
                for (int i = 0; i < num; i++)
                {
                    j = i + 1;
                    while (j < num)
                    {
                        arr[i] = arr[j];
                        i = i + 1;
                        j = j + 1;
                    }
                    num = num - 1;                    
                }
            }
            }   
                        

        public void display()
        {
            if (num == 0)
            {
                Console.WriteLine("\nThe list is empty");
                return;
            }
            Console.WriteLine("\nThe list is\n");
            for (int i = 0; i < num; i++)
            {
                Console.Write(arr[i].ToString() + "\t");
            }
            Console.WriteLine("\n");
        }
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.add();
            char ch;
            while (true)
            {
                Console.Write("\n1. Remove element from the list");
                Console.Write("\n2. Display elements");
                Console.Write("\n3. Exit");
                Console.Write("\nEnter your choice: ");
                ch = Convert.ToChar(Console.ReadLine());
                switch (ch)
                {
                    case '1':
                        {
                            obj.remove();
                        }
                        break;
                    case '2':
                        {
                            obj.display();
                        }
                        break;
                    case '3':
                        {
                            return;
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("Invalid option");
                        }
                        break;
                }
            }

        }
    }
}

