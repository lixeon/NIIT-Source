
public class NewClass 
{
    public int matrix1[][];
    public int matrix2[][];
    
    int matrix_copy[][];
    public NewClass() 
    {
        matrix1 = new int[20][20]; 
        matrix2 = new int[20][20];         
        matrix_copy = new int[20][20];   
    }
    
    public void create()
    {
      for (int i=0; i < matrix1.length; i++)
      {
        for (int j = 0; j < matrix1[i].length; j++) 
        {
            matrix1[i][j] = (i+1);
        }
      }
      for (int i=0; i < matrix2.length; i++)
      {
        for (int j = 0; j < matrix2[i].length; j++) 
        {
            matrix2[i][j] = (i+1);
        }
      }
      
     for (int i=0; i < matrix_copy.length; i++)
      {
        for (int j = 0; j < matrix_copy[i].length; j++) 
        {
            matrix_copy[i][j] = (i+1);
        }
      }
    }
    
    public void modify_1()
    {
        int val=0;
     
        for (int i=0; i < matrix1.length; i++)
        {
          for (int j = 0; j < matrix1[i].length; j++) 
            {
                val=0;    
                for (int k=0; k < matrix1.length; k++)
                {
                     for (int l = 0; l < matrix1[k].length; l++) 
                        {
                            val+=matrix_copy[k][l];
                        }
                }                                            
                 matrix1[i][j]=(matrix1[i][j]+val);              
            }
         }
    }    
     public void modify_2()
    {
        int val=0;
     
        for (int i=0; i < matrix2.length; i++)
        {
          for (int j = 0; j < matrix2[i].length; j++) 
            {
                val=0;    
                for (int k=0; k < matrix2.length; k++)
                {
                     for (int l = 0; l < matrix2[k].length; l++) 
                        {
                            val+=matrix_copy[k][l];
                        }
                }                                            
                 matrix2[i][j]=(matrix2[i][j]-val);                  
            }
         }
    }
     
    public void display()
    {
      System.out.println("\nModified matrix 1 is...\n");  
      for (int i=0; i < matrix1.length; i++)
      {
        for (int j = 0; j < matrix1[i].length; j++) 
        {
            System.out.print(matrix1[i][j]+"   ");
        }
        System.out.println();
      }
      
      System.out.println("\nModified matrix 2 is...\n");  
      for (int i=0; i < matrix2.length; i++)
      {
        for (int j = 0; j < matrix2[i].length; j++) 
        {
            System.out.print(matrix2[i][j]+"   ");
        }
        System.out.println();
      }
    }
     
     public static void main(String args[])
     {
        NewClass m=new NewClass();
        m.create();       
        m.modify_1();
        m.modify_2();
        m.display();  
     }
}