
public class NewClass {
    
    /** Creates a new instance of NewClass */
    public NewClass() {
    }
     public int[] arr=new int[100];
    public void calculate()
    {
        for(int i=0;i<arr.length;i++)
        {
            arr[i]=(i+2);
        }
        System.out.println("The loop starts....");
        for(int i=0;i<100;i++)
        {
            System.out.println("The elements in the array are....");
            display();   
            increment();
        }       
    }  
    
    public void increment()
    {
        for(int i=0;i<arr.length;i++)
        {
            arr[i]=arr[i]+1;
        }
    }
    public void display()
    {
        for(int i=0;i<arr.length;i++)
        {
            System.out.print(arr[i] + "   ");
        }
       System.out.println("The sum is ");
       add();
    } 
    
    public void add()
    {
        int sum=0;
        for(int i=0;i<arr.length;i++)
        {
            sum+=arr[i];            
        }
        System.out.println(sum);
    }   
          
    public static void main(String[] args)
    {
        NewClass m=new NewClass();
        m.calculate();  
        System.out.println("Back to main");
    }
    
}
