using System;
using System.Collections.Generic;
using System.Text;

namespace MyApp
{
    class Program
    {
        int large,small;
        int n = 10000;
        int[] operand;
        public void accept()
        {
            Random rnd = new Random();            
            operand = new int[n];

            for (int i = 0; i < n; i++)
            {
                operand[i] = Convert.ToInt32((rnd.Next() % 1000) + 1);
            }
            for (int i = 0; i < n; i++)
            {
                Console.Write(operand[i].ToString()+"\t");
            }
            find();
        }
        public void find()
        {            
            large = small = operand[0];
            for (int i = 0; i < n; i++)
            {
                for (int j = 1; j < n; j++)
                {
                    if (large < operand[j])
                    {
                        large = operand[j];
                    }
                }
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 1; j < n; j++)
                {
                    if (small > operand[j])
                    {
                        small = operand[j];
                    }
                }
            }

            display();            
        }

        public void display()
        {
            Console.Write("\nThe largest number is: " + large);
            Console.Write("\nThe smallest number is: " + small);
        }

        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.accept();            
            Console.ReadLine();
        }
    }
}

