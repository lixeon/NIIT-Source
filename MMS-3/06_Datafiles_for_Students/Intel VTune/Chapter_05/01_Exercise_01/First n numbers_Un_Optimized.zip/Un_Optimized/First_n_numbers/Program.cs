using System;
using System.Collections.Generic;
using System.Text;

namespace First_n_numbers
{
    class Program
    {
        int sum_even,sum_odd, sum_prime;
        int n = 10000;
        public void generate()
        {           
            for (int i = 0; i <= n; i++)
            {                
                if (i % 2 == 0)
                {                
                  sum_even += i;
                }
            }
           
            for (int i = 0; i <= n; i++)
            {                
                if (i % 2 != 0)
                {                    
                    sum_odd += i;
                }
            }             
            
            for (int i = 0; i <= n; i++)
            {
                if (isPrime(i))
                {                   
                    sum_prime += i;
                }
            }
            }
            public static bool isPrime(int num)
            {
            bool prime = true;
            for (int i = 2; i <= num / 2; i++)
            {
                if (num % i == 0)
                {
                    prime = false;
                    break;
                }
            }
            return (prime);
            }
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.generate();
            Console.WriteLine("\nSum of even numbers: " + obj.sum_even);
            Console.WriteLine("\nSum of odd numbers: " + obj.sum_odd);
            Console.WriteLine("\nSum of prime numbers: " + obj.sum_prime);

            Console.ReadLine();
        }
        }
        

      
        
    }

