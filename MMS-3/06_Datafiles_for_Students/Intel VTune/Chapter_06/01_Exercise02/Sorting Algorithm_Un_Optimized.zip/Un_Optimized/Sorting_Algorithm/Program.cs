using System;
using System.Collections.Generic;
using System.Text;

namespace Sorting_Algorithm
{
    class Program
    {
        public int[] arr;
        int num=10000;
        public void generate()
        {
            Random rnd = new Random();        
            arr = new int[10000];
            for (int i = 0; i < num; i++)
            {
                arr[i] = Convert.ToInt32((rnd.Next() % 1000) + 1);
            }

            Console.WriteLine("The random numbers are:");
            for (int i = 0; i < num; i++)
            {
                Console.Write("\t " + arr[i]);
            }
        }

        public void BubbleSortArray()
        {
            for (int i = 1; i < num; i++)  
            {              
                for (int j = 0; j < num - i; j++)
                {
                    if (arr[j] > arr[j + 1])  
                    {                      
                        int temp;
                        temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }

            Console.WriteLine("\n\n\nThe sorted list is.........\n");
            for (int i = 0; i < num; i++)
            {
                Console.Write("\t " + arr[i]);
            }            
        }
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.generate();
            obj.BubbleSortArray();
            Console.ReadLine();
        }
    }
}
