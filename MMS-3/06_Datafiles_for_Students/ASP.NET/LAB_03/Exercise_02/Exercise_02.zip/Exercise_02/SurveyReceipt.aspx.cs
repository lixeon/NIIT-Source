using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class SurveyReciept : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();
        }

        TextBox txtName = (TextBox)PreviousPage.Master.FindControl("MainContent").FindControl("txtName");
        RadioButtonList optGender = (RadioButtonList)PreviousPage.Master.FindControl("MainContent").FindControl("optGender");
        CheckBoxList chkCategory = (CheckBoxList)PreviousPage.Master.FindControl("MainContent").FindControl("chkCategory");
        TextBox txtPublication = (TextBox)PreviousPage.Master.FindControl("MainContent").FindControl("txtPublication");
        HtmlInputText txtMail = (HtmlInputText)PreviousPage.Master.FindControl("MainContent").FindControl("txtMail");
        HtmlInputRadioButton optFormat1 = (HtmlInputRadioButton)PreviousPage.Master.FindControl("MainContent").FindControl("Radio1");
        HtmlInputRadioButton optFormat2 = (HtmlInputRadioButton)PreviousPage.Master.FindControl("MainContent").FindControl("Radio2");


        string sName = txtName.Text.ToString();
        string sGender = optGender.SelectedValue.ToString();
        string sCategory = "";
        foreach (ListItem category in chkCategory.Items)
        {
            if (category.Selected)
            {
                sCategory += category.Text + "<br>";
            }
        }
        string sPublication = txtPublication.Text.ToString();
        string sMail = txtMail.Value.ToString();
        string sFormat = "Not Selected";
        if (optFormat1.Checked)
            sFormat = optFormat1.Value.ToString();
        if (optFormat2.Checked)
            sFormat = optFormat2.Value.ToString();


        lblName.Text = "Thank you " + sName + " for completing the survey. You have entered the following details:<br><br>";
        lblGender.Text = sGender;
        lblCategory.Text = sCategory;
        lblPublication.Text = sPublication;
        lblMail.Text = sMail;
        lblFormat.Text = sFormat;

       
    }
}
