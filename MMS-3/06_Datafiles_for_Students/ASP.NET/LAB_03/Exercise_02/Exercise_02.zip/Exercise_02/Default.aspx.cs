using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{  

   protected void Page_Load(object sender, EventArgs e)
    {
        string sHitCount = (Application["HitCount"]).ToString();
        lblHitCount.Text = "This website has been visited " + sHitCount + " time(s)";


        if (Session["UserName"] != null)
        {
            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();
        }

        Random rndGen = new Random();
        int rndNum = rndGen.Next(10);
        if (rndNum < 5)
            imgBooks.ImageUrl = "Image1.jpg";
        else
            imgBooks.ImageUrl = "Image3.jpg";
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (txtName.Text != "")
        {
            Session["UserName"] = txtName.Text;
            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();
        }
    }
}
