using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class BrowserCompatibility : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();
        }
        HttpBrowserCapabilities currentBrowser = Request.Browser;
        lblBrowserAct.Text = currentBrowser.Browser + "  " + currentBrowser.Version;
        lblPlatformAct.Text = currentBrowser.Platform.ToString();
        lblTableAct.Text = currentBrowser.Tables.ToString();
        lblCookieAct.Text = currentBrowser.Cookies.ToString();
        lblScriptAct.Text = currentBrowser.VBScript.ToString();
        lblECMAAct.Text = currentBrowser.EcmaScriptVersion.ToString();      
    }
}
