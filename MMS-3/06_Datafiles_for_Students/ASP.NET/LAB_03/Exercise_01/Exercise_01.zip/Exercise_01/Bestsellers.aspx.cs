using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class BookReviews : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {

            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();
        }
        WebService myservice = new WebService();
        string[] sBookReviews = myservice.GetReviews();
        if (!IsPostBack)
        {
            foreach (string c in sBookReviews)
            {
                ddBookReviews.Items.Add(c);

            }
        }

    }  

    private string GetReview(string Value)
    {
        string htmlResult = "<p><b>Review: </b>";
        WebService myservice = new WebService();
        string sReview = myservice.bookReview(Value);
        htmlResult += "" + sReview + "<br/>";
        htmlResult += "</p>";
        return htmlResult;
    }
   
}
