using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Caching;

public partial class BookReviews : System.Web.UI.Page
{
    private CacheItemRemovedCallback onRemove = null;

    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();
        }

        BestSellerReviews.WebService myservice = new BestSellerReviews.WebService();
        string finalVersion = (string)Cache["FinalVersion"];
       
            if (finalVersion == null)
            {
                finalVersion = myservice.FinalVersion();
                Cache.Insert("FinalVersion", finalVersion, null, Cache.NoAbsoluteExpiration, Cache.NoSlidingExpiration, CacheItemPriority.Normal, onRemove);
            }

            string[] categories = (string[])Cache["CacheBookReviews"];
            if (categories == null)
            {
                categories = myservice.GetReviews();
                string[] sDependencies = new string[1];
                sDependencies[0] = "FinalVersion";
                CacheDependency dependency = new CacheDependency(null, sDependencies);
                Cache.Insert("CacheBookReviews", categories, dependency);
            }

            if (!IsPostBack)
            {
                ddBookReviews.Items.Clear();
                foreach (string c in categories)
                {
                    ddBookReviews.Items.Add(c);

                }
            }          
   
    }
        
    
    protected void Page_PreRender(object sender, EventArgs e)
    {
        ArrayList alBookReviews = (ArrayList)Session["BookReviews"];
        if (alBookReviews == null)
        {
            lblBook.Text += "";
        }
        else
        {
            lblBook.Text = "";
            foreach (string str in alBookReviews)
            {
                lblBook.Text += str + "<br />";
            }
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        ArrayList alBookReviews = (ArrayList)Session["BookReviews"];
        if (alBookReviews == null)
        {
            alBookReviews = new ArrayList();
        }
        alBookReviews.Add(ddBookReviews.Text);
        Session["BookReviews"] = alBookReviews;
    }
   private string GetReview(string Value)
    {       
            string htmlResult = "<p><b>Review: </b>";
            BestSellerReviews.WebService myservice = new BestSellerReviews.WebService();
            string sReview = myservice.bookReview(Value);
            htmlResult += "" + sReview + "<br/>";
            htmlResult += "</p>";
            return htmlResult;       
    }

    protected void btnCheck_Click(object sender, EventArgs e)
    {

        BestSellerReviews.WebService myservice = new BestSellerReviews.WebService();
        string cVersion = (string)Cache["FinalVersion"];
        if (cVersion != myservice.FinalVersion())
        {
            Cache.Remove("FinalVersion");
            Response.Redirect("Default.aspx");
        }
    }

    public void RemovedCallback(string key, object value, CacheItemRemovedReason callbackReason)
    {
        BestSellerReviews.WebService myservice = new BestSellerReviews.WebService();
        Cache["FinalVersion"] = myservice.FinalVersion();
        string[] category = myservice.GetReviews();
        Cache["CacheBookReviews"] = category;
        ddBookReviews.Items.Clear();
        foreach (string item in category)
            ddBookReviews.Items.Add(item);
    }
    protected void ddBookReviews_SelectedIndexChanged(object sender, EventArgs e)
    {       
       lblReview.Text = GetReview(ddBookReviews.Text);        
        
    }
}
