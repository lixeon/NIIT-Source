using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ShoppingCart : System.Web.UI.Page
{
    private double price;
    private int rowCount;
    private string sUserName;
   
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
                     
                sUserName = Session["UserName"].ToString();
                string dbConn = ConfigurationManager.ConnectionStrings["NTBS"].ConnectionString;
                System.Data.SqlClient.SqlConnection sqlConn = new System.Data.SqlClient.SqlConnection(dbConn);
                sqlConn.Open();
                System.Data.SqlClient.SqlCommand counterCommand = new System.Data.SqlClient.SqlCommand(
                    "SELECT COUNT(*) FROM ShoppingCart where UserName='" + sUserName + "'", sqlConn);
                rowCount = (int)counterCommand.ExecuteScalar();
            }
           
       
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Label lblMaster = (Label)Master.FindControl("lblMaster");
        lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();
       
        lblUserName.Text = Session["UserName"].ToString();            
          
    }
}
