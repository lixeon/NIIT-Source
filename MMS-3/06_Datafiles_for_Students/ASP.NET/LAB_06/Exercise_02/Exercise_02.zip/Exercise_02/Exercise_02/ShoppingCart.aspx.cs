using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ShoppingCart : System.Web.UI.Page
{
    private double price;
    private int rowCount;
    private string sUserName;
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            if (!(Roles.IsUserInRole(Session["UserName"].ToString(), "Admins")))
            {
                Page.MasterPageFile = "~/Member.Master";
                Label lblMaster = (Label)Master.FindControl("lblMaster");
                lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();
                Page.MasterPageFile = "~/Member.Master";
                sUserName = Session["UserName"].ToString();


                string dbConn = ConfigurationManager.ConnectionStrings["NTBS"].ConnectionString;
                System.Data.SqlClient.SqlConnection sqlConn = new System.Data.SqlClient.SqlConnection(dbConn);
                sqlConn.Open();
                System.Data.SqlClient.SqlCommand counterCommand = new System.Data.SqlClient.SqlCommand(
                    "SELECT COUNT(*) FROM ShoppingCart where UserName='" + sUserName + "'", sqlConn);
                rowCount = (int)counterCommand.ExecuteScalar();
            }
            else
                Page.MasterPageFile = "~/Admin.Master";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
       
            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();
       
        lblUserName.Text = Session["UserName"].ToString();

        if (((Page.IsPostBack) && (rowCount <= 1)) || (rowCount == 0))
        {
            Table tblOptions = new Table();
            TableRow r1 = new TableRow();
            TableCell r1c1 = new TableCell();
            Button btnBrowse = new Button();
            btnBrowse.Text = "Browse Products";
            btnBrowse.Font.Bold = true;
            btnBrowse.Style.Add("cursor", "hand");
            btnBrowse.Click += new EventHandler(btnBrowseClick);
            tblOptions.Width = Unit.Percentage(50);
            tblOptions.ForeColor = System.Drawing.Color.DarkSlateBlue;
            r1c1.HorizontalAlign = HorizontalAlign.Left;
            r1c1.Controls.Add(btnBrowse);
            r1.Cells.Add(r1c1);            
            tblOptions.Rows.Add(r1);        

            TdPageLayout.Controls.Add(tblOptions);
            
            gvwCart.EmptyDataTemplate = new CartTemplate();
        }

        
        System.Data.SqlClient.SqlConnection sqlConn =
            new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["NTBS"].ConnectionString);
        sqlConn.Open();
        System.Data.SqlClient.SqlDataReader dr;
        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(
                "SELECT SUM(BookPrice*Quantity) FROM ShoppingCart where UserName='" + Session["UserName"].ToString() + "'", sqlConn);
        dr = cmd.ExecuteReader();
   
        dr.Read();
        if (!dr.IsDBNull (0))
        {
            price = dr.GetDouble(0);
            dr.Close();
        }
    }

    protected void btnBrowseClick(object sender, EventArgs e)
    {
        Response.Redirect("~/BookDetails.aspx");
    }
}
public class CartTemplate : ITemplate
{
   public void InstantiateIn(System.Web.UI.Control container)
    {
        Literal lc = new Literal();       
        lc.Text = "There are no items in your shopping cart<BR>Please click <b>Browse products</b> to continue";        
        container.Controls.Add(lc);
    }
}
