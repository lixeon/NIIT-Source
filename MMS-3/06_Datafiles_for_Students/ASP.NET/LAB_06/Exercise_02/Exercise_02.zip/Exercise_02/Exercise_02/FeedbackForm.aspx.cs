using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class FeedbackForm : System.Web.UI.Page
{
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            if (!(Roles.IsUserInRole(Session["UserName"].ToString(), "Admins")))
                Page.MasterPageFile = "~/Member.Master";
            else
                Page.MasterPageFile = "~/Admin.Master";
        }
    }

    protected void Feedback_Command(object sender, CommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "HomeDelivery":
                {
                    Server.Transfer("YourFeedback.aspx?Feedback=HomeDelivery");
                    break;
                }
            case "Search":
                {
                    Server.Transfer("YourFeedback.aspx?Feedback=Search");
                    break;
                }
            case "User":
                {
                    Server.Transfer("YourFeedback.aspx?Feedback=User");
                    break;
                }
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();

        }

    }  

   

   
}
