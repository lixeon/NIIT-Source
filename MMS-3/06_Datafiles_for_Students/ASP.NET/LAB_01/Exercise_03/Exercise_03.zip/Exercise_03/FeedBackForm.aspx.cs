using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class FeedBackForm : System.Web.UI.Page
{
    //protected void Page_Error(object sender, EventArgs e)
    //{

    //        Response.Write("The following error occurred:<br />");
    //        Response.Write(Server.GetLastError().Message);
    //        Response.Write("<br /><a href='Default.aspx'>Click here to continue</a>");
    //        Server.ClearError(); 
    //}

    protected void Feedback_Command(object sender, CommandEventArgs e)
    {
       switch (e.CommandName)
        {
            case "HomeDelivery":
                {
                    Server.Transfer("YourFeedback.aspx?Feedback=HomeDelivery");
                    break;
                }
            case "Search":
                {
                    Server.Transfer("YourFeedback.aspx?Feedback=Search");
                    break;
                }
            case "Design":
                {
                    Server.Transfer("YourFeedback.aspx?Feedback=Design");
                    break;
                }
        }     
   
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //txtFeedback.Enabled = false;
        //Exception customException = new Exception("Test Error");
        //throw customException;

    }

   
}
