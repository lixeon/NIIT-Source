using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{
    private string Book1 = "ID: 1234<BR>Title: Cold Mountain<BR>Author: John Williams<BR>Price: $56<br>";
    private string Book2 = "ID: 5678<BR>Title: Beyond Code<BR>Author: Mark<BR>Price: $233<br>";
    private string Book3 = "ID: 1234<BR>Title: Digital Logic<BR>Author: Tom Wright<BR>Price: $90<br>";

    protected void View_Click(object sender, EventArgs e)
    {
        Button btnClicked = (Button)sender;
        if (btnClicked.ID == "btnDetail1")
            lblBookDetails.Text = Book1;
        else if (btnClicked.ID == "btnDetail2")
            lblBookDetails.Text = Book2;
        else if (btnClicked.ID == "btnDetail3")
            lblBookDetails.Text = Book3;

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Random rndGen = new Random();
        int rndNum = rndGen.Next(10);
        if (rndNum < 5)
            imgBooks.ImageUrl = "Image1.jpg";
        else
            imgBooks.ImageUrl = "Image3.jpg";
    }
}
