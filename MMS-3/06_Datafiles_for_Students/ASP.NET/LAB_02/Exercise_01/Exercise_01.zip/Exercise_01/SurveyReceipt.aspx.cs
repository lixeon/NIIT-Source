using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class SurveyReceipt1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox txtName = (TextBox)PreviousPage.FindControl("txtName");
        RadioButtonList optGender = (RadioButtonList)PreviousPage.FindControl("optGender");
        CheckBoxList chkCategory = (CheckBoxList)PreviousPage.FindControl("chkCategory");
        TextBox txtPublication = (TextBox)PreviousPage.FindControl("txtPublication");
        HtmlInputText txtMail = (HtmlInputText)PreviousPage.FindControl("txtMail");


        string sName = txtName.Text.ToString();
        string sGender = optGender.SelectedValue.ToString();
        string sCategory = "";
        foreach (ListItem category in chkCategory.Items)
        {
            if (category.Selected)
            {
                sCategory += category.Text + "<br>";
            }
        }
        string sPublication = txtPublication.Text.ToString();
        string sMail = txtMail.Value.ToString();
        string sFormat = Request.Form["optFormat"];


        lblName.Text = "Thank you "+ sName+" for completing the survey. You have entered the following details:<br><br>";
        lblGender.Text = sGender;
        lblCategory.Text = sCategory;
        lblPublication.Text = sPublication;
        lblMail.Text = sMail;
        lblFormat.Text = sFormat;
    }
}
