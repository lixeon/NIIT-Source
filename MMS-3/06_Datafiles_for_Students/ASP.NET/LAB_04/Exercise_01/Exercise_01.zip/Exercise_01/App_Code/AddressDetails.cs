using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for AddressDetails
/// </summary>
public class AddressDetails
{
	public AddressDetails()
	{
    }

    public string getRegion()
    {     
          string address =
            "<Country>"
                + "<Region RegionName='USA'><Area AreaName='Washington'>"
                    + "<Contact ContactDetails='North Seattle'></Contact>"
                    + "<Contact ContactDetails='Snoquamish'></Contact>"
                + "</Area></Region>"
                + "<Region RegionName='Southern Europe'>"
                    + "<Area AreaName='Italy'>"
                        + "<Contact ContactDetails='Giro Alps'></Contact>"
                        + "<Contact ContactDetails='Giro Napoli'></Contact>"
                        + "<Contact ContactDetails='Giro Sicily'></Contact>"
                    + "</Area>"
                    + "<Area AreaName='Spain'>"
                        + "<Contact ContactDetails='Basque'></Contact>"
                        + "<Contact ContactDetails='Valencia Route'></Contact>"
                    + "</Area>"
                + "</Region>"
                + "<Region RegionName='Western Europe'>"
                    + "<Area AreaName='Eire'>"
                        + "<Contact ContactDetails='Cork 2-Day Route'></Contact>"
                        + "<Contact ContactDetails='North Kerry'></Contact>"
                    + "</Area>"
                    + "<Area AreaName='UK'>"
                        + "<Contact ContactDetails='North Wales'></Contact>"
                        + "<Contact ContactDetails='Pennine Way'></Contact>"
                    + "</Area>"
                + "</Region>"
            + "</Country>";
        return address;
    }

    public string getAddress(string country)
    {
        string sAddress;
        switch (country)
        {
            case "North Seattle":
                {
                    sAddress="Block A, Qtr-42, Pusa Road";
                }
                break;

            case "Snoquamish":
                {
                    sAddress = "Block B, Qtr-42, Pusa Road";
                }
                break;

            case "Giro Alps":
                {
                    sAddress = "Block A/22, Qtr-434, MG Road";
                }
                break;

            case "Giro Napoli":
                {
                    sAddress = "Building No.4, Block C/2, Qtr-42, Pusa Road";
                }
                break;

            case "Giro Sicily":
                {
                    sAddress = "Building No.8, Block X/2, Qtr-78";
                }
                break;

            case "Basque":
                {
                    sAddress = "Building No.2, Block A/11, Qtr-2";
                }
                break;

            case "Valencia Route":
                {
                    sAddress = "Building No.10, Block C/2, Qtr-42, Grahm Road";
                }
                break;

            case "Cork 2-Day Route":
                {
                    sAddress = "Block C/2, Qtr-42, Gems Road ";
                }
                break;

            case "North Kerry":
                {
                    sAddress = "Building No.14, Block 11/2, Qtr-45";
                }
                break;

            case "North Wales":
                {
                    sAddress = "Building No.45, Block A/2, Qtr-42, MG Road ";
                }
                break;

            case "Pennine Way":
                {
                    sAddress = "Building No.12, Block C/2, Qtr-42, NH-8 ";
                }
                break;
            default:
                {
                    sAddress = "";
                }
                break;
        }
       return sAddress;
    }
}
