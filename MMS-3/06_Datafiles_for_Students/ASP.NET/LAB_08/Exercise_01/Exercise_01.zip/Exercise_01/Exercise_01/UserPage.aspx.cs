using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class UserPage : System.Web.UI.Page
{
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            if (!(Roles.IsUserInRole(Session["UserName"].ToString(), "Admins")))
                Page.MasterPageFile = "~/Member.Master";
            else
                Page.MasterPageFile = "~/Admin.Master";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string sCategory = this.Page.Request.QueryString["Category"].ToString();
        System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter
        ("SELECT Title, Author, Publisher, Categoryname 'Category', ISBN, Price, Description from BookDetails WHERE CategoryName like'%" + sCategory + "%'", ConfigurationManager.ConnectionStrings["NTBS"].ConnectionString);
        DataSet ds = new DataSet("BookDetails");
        da.Fill(ds, "BookDetails");
        gvwBooks.DataSource = ds;
        gvwBooks.DataBind();   
               
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter
        ("SELECT Title, Author, Publisher, Categoryname 'Category', ISBN, Price, Description from BookDetails WHERE CategoryName like'%" + ddCategory.Text + "%'", ConfigurationManager.ConnectionStrings["NTBS"].ConnectionString);
        DataSet ds = new DataSet("BookDetails");
        da.Fill(ds, "BookDetails");
        gvwBooks.DataSource = ds;
        gvwBooks.DataBind();                   
    }
}
