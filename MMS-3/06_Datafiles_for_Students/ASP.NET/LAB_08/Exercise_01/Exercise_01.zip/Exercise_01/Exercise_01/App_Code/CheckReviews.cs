using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for CheckReviews
/// </summary>
/// 

public class CheckReviews:WebControl
{   
    private string fmtStatusStartColor = "";
    private const string fmtStatusEndColor = "</FONT>";
    private string fmtIntroStartColor = "<FONT color='black'>";
    private const string fmtIntroEndColor = "</FONT>";
    private string status;


    public CheckReviews()
	{
       checkWebService();
	}

    private void checkWebService()
    {
        try
        {
            
            BestSellerReviews.WebService myservice = new BestSellerReviews.WebService();
                      
            string reviews = myservice.GetReviews().ToString();
            fmtStatusStartColor = "<FONT color='blue'>";
            status = fmtStatusStartColor + "Reviews available" + fmtStatusEndColor;
        }
        catch
        {
            fmtStatusStartColor = "<FONT color='red'>";
            status = fmtStatusStartColor + "Reviews not available" + fmtStatusEndColor;

        }
    }

    protected override void RenderContents(HtmlTextWriter writer)
    {
        writer.Write("<HR />" + fmtIntroEndColor + fmtStatusStartColor + status + fmtStatusEndColor + "<HR />");
       // btnUpdate.RenderControl(writer);
    }

    //protected override void CreateChildControls()
    //{
    //        btnUpdate = new Button();
    //        btnUpdate.Style.Add("cursor", "hand");
    //        btnUpdate.Text = "Update";
    //        btnUpdate.Click += new EventHandler(btnUpdateClick);
    //        Controls.Add(btnUpdate);

    //        lcMessage = new Literal();
    //        lcMessage.Text = "<HR />"
    //            + fmtIntroStartColor
    //            + fmtIntroEndColor
    //            + "<BR />"
    //            + fmtStatusStartColor
    //            + status
    //            + fmtStatusEndColor
    //            + "<HR />";
    //        Controls.Add(lcMessage);
        
    //}

    protected void btnUpdateClick(object sender, EventArgs e)
    {
        checkWebService();
    }

    public string FormatIntroStartColor
    {
        set
        {
            fmtIntroStartColor = "<FONT color='" + value + "'>";
        }
    }
}

