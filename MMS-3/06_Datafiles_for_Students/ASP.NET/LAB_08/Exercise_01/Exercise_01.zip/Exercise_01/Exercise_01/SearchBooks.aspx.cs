using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class SearchBooks : System.Web.UI.Page
{
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            if (!(Roles.IsUserInRole(Session["UserName"].ToString(), "Admins")))
                Page.MasterPageFile = "~/Member.Master";
            else
                Page.MasterPageFile = "~/Admin.Master";
        }
    }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString(); 
            ArrayList categories = Profile.Category;
            
            if (categories.Count != 0)
            {
                LiteralControl lcText = new LiteralControl("Search by your favourite category:<br/><br/>");
                pnlCategory.Controls.Add(lcText);
            }
            
            foreach (string category in categories)
            {
                HyperLink link = new HyperLink();
                link.Text = category.ToString();
                link.ForeColor = System.Drawing.Color.Blue;
                link.NavigateUrl = "~/UserPage.aspx?Category=" + link.Text.ToString();
                pnlCategory.Controls.Add(link);
                LiteralControl lcBreak = new LiteralControl("<br/>");
                pnlCategory.Controls.Add(lcBreak);
            }
        } 
   }
   
}

