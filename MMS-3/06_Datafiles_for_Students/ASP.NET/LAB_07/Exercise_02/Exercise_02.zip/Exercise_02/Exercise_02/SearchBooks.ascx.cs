using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class SearchBooks : System.Web.UI.UserControl
{   
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (txtSearch.Text != "")
        {
            lblSearch.Visible = false;
            string sChoice = ddSearchCriteria.Text;
            switch (sChoice)
            {
                case "Author":
                    {
                        System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter
                        ("SELECT Title, Author, Publisher, Categoryname 'Category', ISBN, Price, Description from BookDetails WHERE Author like'%" + txtSearch.Text + "%'", ConfigurationManager.ConnectionStrings["NTBS"].ConnectionString);
                        DataSet ds = new DataSet("BookDetails");
                        da.Fill(ds, "BookDetails");
                        gvwBooks.DataSource = ds;
                        gvwBooks.DataBind();
                    }
                    break;
                case "Title":
                    {
                        System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter
                        ("SELECT Title, Author, Publisher, Categoryname 'Category', ISBN, Price, Description from BookDetails WHERE Title like '%" + txtSearch.Text + "%'", ConfigurationManager.ConnectionStrings["NTBS"].ConnectionString);
                        DataSet ds = new DataSet("BookDetails");
                        da.Fill(ds, "BookDetails");
                        gvwBooks.DataSource = ds;
                        gvwBooks.DataBind();
                    }
                    break;
                case "Publisher":
                    {
                        System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter
                        ("SELECT Title, Author, Publisher, Categoryname 'Category', ISBN, Price, Description from BookDetails WHERE Publisher like'%" + txtSearch.Text + "%'", ConfigurationManager.ConnectionStrings["NTBS"].ConnectionString);
                        DataSet ds = new DataSet("BookDetails");
                        da.Fill(ds, "BookDetails");
                        gvwBooks.DataSource = ds;
                        gvwBooks.DataBind();
                    }
                    break;

            }
        }
        else
        {
            lblSearch.Visible = true;
        }
    }
}
