using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AddToCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        double price = 0;
        if (Session["UserName"] != null)
        {
            string UserName = Session["UserName"].ToString();
            Label1.Text = Session["UserName"].ToString();
            try
            {
                string BookID = Request.QueryString["BookID"].ToString();

                System.Data.SqlClient.SqlConnection sqlConn =
                    new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["NTBS"].ConnectionString);
                sqlConn.Open();
                System.Data.SqlClient.SqlDataReader dr;
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(
                        "SELECT Price FROM BookDetails where BookId='" + BookID + "'", sqlConn);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    price = dr.GetDouble(0);
                }
                dr.Close();
                System.Data.SqlClient.SqlDataReader cartReader;
                System.Data.SqlClient.SqlCommand cartCommand = new System.Data.SqlClient.SqlCommand(
                    "SELECT Quantity FROM ShoppingCart where BookId='" + BookID + "' and UserName='" + Session["UserName"].ToString() + "'", sqlConn);
                cartReader = cartCommand.ExecuteReader();
                if (cartReader.HasRows)
                {
                    cartReader.Read();
                    int qty = cartReader.GetInt32(0) + 1;
                    cartReader.Close();
                    System.Data.SqlClient.SqlCommand cartAdder = new System.Data.SqlClient.SqlCommand(
                        "UPDATE ShoppingCart"
                        + " SET Quantity = " + qty
                        + " WHERE BookId = " + BookID, sqlConn);

                    cartAdder.ExecuteNonQuery();
                    Response.Redirect("ShoppingCart.aspx");

                }
                else
                {
                    cartReader.Close();
                    System.Data.SqlClient.SqlCommand cartAdder = new System.Data.SqlClient.SqlCommand(
                        "INSERT into ShoppingCart (UserName, BookId, BookPrice, Quantity, DateCreated)"
                        + " VALUES ('" + UserName + "','" + BookID + "'," + price + ",1,'" + DateTime.Now.ToString() + "')", sqlConn);
                    cartAdder.ExecuteNonQuery();
                    Response.Redirect("ShoppingCart.aspx");
                }
            }
            catch
            {
                Response.Write("An error has occured<BR>");
                Response.Write("<A href='Default.aspx'>Home</A>");

            }
        }
        else
        {
            Response.Write("You first need to log in to add items in your cart.<BR>");
            Response.Write("<A href='Default.aspx'>Home</A>");
        }
    }
       
}
