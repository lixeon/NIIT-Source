using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for DiscountCalculator
/// </summary>
/// 
public class TemplateOwner : WebControl
{
}

public class DiscountCalculator : CompositeControl
{

    private ITemplate theTemplate;
    private TemplateOwner theTemplateOwner;

    public TemplateOwner TemplateOwner
    {
        get
        {
            return theTemplateOwner;
        }
    }
    public ITemplate Template
    {
        get
        {
            return theTemplate;
        }
        set
        {
            theTemplate = value;
        }
    }

    public DiscountCalculator() { }

    private Label lblPrice;
    private Label lblDiscount;

    private double price;
    private double discountRate;
    private double increasedDiscount;
    private double IncreasedDiscountPrice;
    private double amountPayable;


    public double totalPrice
    {
        set
        {
            price = value;
        }
    }

    public double normalDiscountRate
    {
        set
        {
            discountRate = 10;
        }
    }

    public double increasedDiscountRate
    {
        set
        {
            increasedDiscount = 15;
        }
    }

    public double priceForIncreasedDiscount
    {
        set
        {
            IncreasedDiscountPrice = 200;
        }
    }

    protected override void CreateChildControls()
    {
        if (price == 0)
        {
            theTemplateOwner = new TemplateOwner();
            if (theTemplate == null)
            {
                theTemplate = new BlankSection();
            }
            theTemplate.InstantiateIn(theTemplateOwner);
            Controls.Add(theTemplateOwner);
            return;
        }

        lblPrice = new Label();
        lblPrice.ForeColor = System.Drawing.Color.Black;
        lblPrice.Visible = false;

        lblDiscount = new Label();
        lblDiscount.Text = "Discount: ";
        lblDiscount.ForeColor = System.Drawing.Color.Black;
        lblDiscount.Visible = false;

        Controls.Add(lblPrice);

        Controls.Add(new LiteralControl("<br/>"));
        Controls.Add(lblDiscount);
        lblPrice.Text = "Total price: " + price;


        if (price < 200)
        {
            amountPayable = price - (price * 10 / 100);
            lblDiscount.Text = "Discounted price: " + amountPayable;
            lblPrice.Visible = true;
            lblDiscount.Visible = true;
            Literal lc = new Literal();
            lc.Text = "<br><br/>( Make a purchase greater than 200 and get a discount of 15%)";
            this.Controls.Add(lc);

        }
        else if (price >= 200)
        {
            amountPayable = price - (price * 15 / 100);
            lblDiscount.Text = "Discounted price: " + amountPayable;
            lblPrice.Visible = true;
            lblDiscount.Visible = true;
        }

    }
}

sealed class BlankSection : ITemplate
{
    void ITemplate.InstantiateIn(Control owner)
    {
        Literal lc = new Literal();
        lc.Text = "* Get a discount of 10% on all purchases. <br/>* Make a purchase greater than 200 and get a discount of 15%.";
        owner.Controls.Add(lc);
    }
}

