using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ModifyDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

       
        if (Session["UserName"] != null)
        {
            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();
        }

        if (!Page.IsPostBack)
        {
            MembershipUser userCurrent = Membership.GetUser();
            if (userCurrent != null)
            {
                txtUsername.Text = userCurrent.UserName;
                txtEmail.Text = userCurrent.Email;
            }
            else
            {
                Response.Redirect("~/default.aspx");
            }
        }
    }
  
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        MembershipUser userCurrent = Membership.GetUser();
        if (txtEmail.Text != "")
        {
            userCurrent.Email = txtEmail.Text;
            Membership.UpdateUser(userCurrent);
            lblMail.Visible = true;
        }
        
    }
}
