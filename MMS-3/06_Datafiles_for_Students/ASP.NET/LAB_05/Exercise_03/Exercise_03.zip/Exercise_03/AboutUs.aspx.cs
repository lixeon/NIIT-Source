using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AboutUs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            Label lblMaster = (Label)Master.FindControl("lblMaster");
            lblMaster.Text = "Welcome " + (Session["UserName"]).ToString();

            //HyperLink hprModifyProfile = (HyperLink)Master.FindControl("hModifyProfile");
            //hprModifyProfile.Visible = true;

            //HyperLink hprForgotPasswd = (HyperLink)Master.FindControl("hForgotPassword");
            //hprForgotPasswd.Visible = true;


            //if (Roles.IsUserInRole(Session["UserName"].ToString(), "Admins"))
            //{
            //    HyperLink hAdmin = (HyperLink)Master.FindControl("hAdministrator");
            //    hAdmin.Visible = true;
            //}
        }
    }
}
