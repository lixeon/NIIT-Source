using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AdministratorLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblErrorMsg1.Text = "";
        lblErrorMsg2.Text = "";
        if (!IsPostBack)
        {
            MembershipUserCollection allUsers = Membership.GetAllUsers();
            foreach (MembershipUser userCurrent in allUsers)
            {
                if (Roles.IsUserInRole(userCurrent.UserName, "Members"))
                {
                    lbxMembersRoleMembers.Items.Add(userCurrent.UserName);
                }
                else
                {
                    lbxMembersRoleNonMembers.Items.Add(userCurrent.UserName);
                }
                if (Roles.IsUserInRole(userCurrent.UserName, "Admins"))
                {
                    lbxAdminsRoleMembers.Items.Add(userCurrent.UserName);
                }
                else
                {
                    lbxAdminsRoleNonMembers.Items.Add(userCurrent.UserName);
                }
            }
        }
    }

    protected void btnMembersAdd_Click(object sender, EventArgs e)
    {
        lblErrorMsg2.Text = "";
        string selectedUsername = lbxMembersRoleNonMembers.SelectedValue;
        if (selectedUsername != "")
        {
            if ((!(Roles.IsUserInRole(selectedUsername.ToString(), "Admins"))))
            {
                lblErrorMsg1.Text = "";
                lbxMembersRoleMembers.Items.Add(selectedUsername);
                lbxMembersRoleNonMembers.Items.Remove(selectedUsername);
                if (!Roles.RoleExists("Members"))
                    Roles.CreateRole("Members");
                Roles.AddUserToRole(selectedUsername, "Members");
            }
            else
            {
                lblErrorMsg1.Text = selectedUsername.ToString() + " belongs to the Admins role and cannot be assigned Members role.";
            }
        }
    }
    protected void btnMembersRemove_Click(object sender, EventArgs e)
    {
        lblErrorMsg2.Text = "";
        lblErrorMsg1.Text = "";
        string selectedUsername = lbxMembersRoleMembers.SelectedValue;
        if (selectedUsername != "")
        {
            lbxMembersRoleNonMembers.Items.Add(selectedUsername);
            lbxMembersRoleMembers.Items.Remove(selectedUsername);
            Roles.RemoveUserFromRole(selectedUsername, "Members");
        }
    }
    protected void btnAdminsAdd_Click(object sender, EventArgs e)
    {
        lblErrorMsg1.Text = "";
        string selectedUsername = lbxAdminsRoleNonMembers.SelectedValue;
        if (selectedUsername != "")
        {
            if ((!(Roles.IsUserInRole(selectedUsername.ToString(), "Members"))))
            {
                lblErrorMsg1.Text = "";
                lbxAdminsRoleMembers.Items.Add(selectedUsername);
                lbxAdminsRoleNonMembers.Items.Remove(selectedUsername);
                if (!Roles.RoleExists("Admins"))
                    Roles.CreateRole("Admins");
                Roles.AddUserToRole(selectedUsername, "Admins");
            }
            else
            {
                lblErrorMsg2.Text = selectedUsername.ToString() + " belongs to the Members role and cannot be assigned Admins role.";
            }
        }
    }
    protected void btnAdminRemove_Click(object sender, EventArgs e)
    {
        lblErrorMsg2.Text = "";
        lblErrorMsg1.Text = "";
        string selectedUsername = lbxAdminsRoleMembers.SelectedValue;
        if (selectedUsername != "")
        {
            lbxAdminsRoleNonMembers.Items.Add(selectedUsername);
            lbxAdminsRoleMembers.Items.Remove(selectedUsername);
            Roles.RemoveUserFromRole(selectedUsername, "Admins");
        }
    }
}
